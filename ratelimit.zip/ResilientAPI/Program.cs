using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Adiciona servi�os necess�rios ao container de DI
builder.Services.AddControllers(); // Adiciona suporte para controladores
builder.Services.AddEndpointsApiExplorer(); // Gera pontos de extremidade para APIs
builder.Services.AddSwaggerGen(); // Adiciona suporte ao Swagger

// Adiciona HttpClient para inje��o de depend�ncia
builder.Services.AddHttpClient(); // Registra o HttpClient para ser injetado

var app = builder.Build();

// Configura��o do Swagger para o ambiente de desenvolvimento
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configura��o do pipeline de middleware
app.UseRouting();
app.UseAuthorization();

// Configura os endpoints para os controladores
app.MapControllers();

// Inicia o aplicativo
app.Run();
