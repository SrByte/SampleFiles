﻿using Microsoft.AspNetCore.Mvc;
using Polly;
using Polly.RateLimit;
using Polly.Retry;
using Polly.Fallback;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace RateLimitApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TrafficController : ControllerBase
    {
        private const int RateLimit = 10; // Máximo de requisições permitidas
        private const int MaxRetryAttempts = 3; // Máximo de tentativas de retry
        private static readonly TimeSpan RetryDelay = TimeSpan.FromSeconds(1); // Intervalo entre tentativas
        private static readonly TimeSpan RateLimitPeriod = TimeSpan.FromMinutes(1); // Período para limitar requisições

        private readonly AsyncRateLimitPolicy _rateLimiterPolicy;
        private readonly AsyncRetryPolicy<object> _retryPolicy;
        private readonly AsyncFallbackPolicy<object> _fallbackPolicy;

        private readonly HttpClient _httpClient;

        public TrafficController(HttpClient httpClient)
        {
            _httpClient = httpClient;

            // Política de rate limit
            _rateLimiterPolicy = Policy
                .RateLimitAsync(RateLimit, RateLimitPeriod);

            // Política de retry
            _retryPolicy = Policy<object>
                .Handle<Exception>()
                .WaitAndRetryAsync(
                    MaxRetryAttempts,
                    attempt => RetryDelay,
                    onRetry: (exception, timeSpan, retryCount, context) =>
                    {
                        Debug.WriteLine($"Tentativa {retryCount} falhou: {exception.Exception.Message}");
                    });

            // Política de fallback
            _fallbackPolicy = Policy<object>
                .Handle<Exception>()
                .FallbackAsync(
                    fallbackValue: GetJsonPlaceholderDataAsync(),
                    onFallbackAsync: async (exception, context) =>
                    {
                        Debug.WriteLine($"Fallback ativado devido à falha: {exception.Exception.Message}");
                    });
        }

        [HttpGet("Test")]
        public async Task<IActionResult> GetTrafficAsync()
        {
            Stopwatch stopwatch = Stopwatch.StartNew();

            try
            {
                // Executa as políticas encapsuladas
                var result = await ExecuteWithPoliciesAsync();

                stopwatch.Stop();

                return Ok(new
                {
                    Message = "Sucesso sem problemas!!",
                    ElapsedTimeInMilliseconds = stopwatch.Elapsed.TotalMilliseconds,
                    Data = result
                });
            }
            catch (RateLimitRejectedException)
            {
                Debug.WriteLine($"Rate limit rejeitado em: {DateTime.Now}");
                return StatusCode(StatusCodes.Status429TooManyRequests, "Rate limit exceeded");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Falha após {MaxRetryAttempts} tentativas: {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // Método auxiliar para encapsular as políticas
        private async Task<object> ExecuteWithPoliciesAsync()
        {
            return await _fallbackPolicy.ExecuteAsync(() =>
                _retryPolicy.ExecuteAsync(() =>
                    _rateLimiterPolicy.ExecuteAsync(GetBaconIpsumDataAsync)));
        }

        // Busca dados da API Bacon Ipsum
        private async Task<object> GetBaconIpsumDataAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync("https://baconipsum.com/api/?type=all-meat&paras=1");
                return response;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Erro ao obter dados do Bacon Ipsum: {ex.Message}");
                throw;
            }
        }

        // Busca dados do JSONPlaceholder (fallback)
        private async Task<object> GetJsonPlaceholderDataAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync("https://jsonplaceholder.typicode.com/posts");
                return response;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Erro ao obter dados do JSONPlaceholder: {ex.Message}");
                throw; // Caso o fallback também falhe, propaga o erro
            }
        }
    }
}
