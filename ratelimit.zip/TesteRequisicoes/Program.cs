﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.Http;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        // Configura o contêiner de serviços e registra o IHttpClientFactory
        var serviceProvider = new ServiceCollection()
            .AddHttpClient() // Registra o IHttpClientFactory para uso
            .BuildServiceProvider();

        // Obtém uma instância de IHttpClientFactory
        var httpClientFactory = serviceProvider.GetRequiredService<IHttpClientFactory>();

        // Endereço do servidor
        //const string baseAddress = "https://localhost:7007/Traffic/Test";
        const string baseAddress = "https://localhost:7007/Retry/Test";

        // Número de requisições simultâneas (configurável)
        const int numberOfRequests = 100;

        Console.WriteLine($"Enviando {numberOfRequests} requisições para {baseAddress}...\n");

        // Executa o teste de requisições
        await SendRequestsAsync(baseAddress, numberOfRequests, httpClientFactory);

        Console.WriteLine("\nTeste concluído.");
    }

    static async Task SendRequestsAsync(string url, int numberOfRequests, IHttpClientFactory httpClientFactory)
    {
        var tasks = new Task[numberOfRequests];

        // Cria uma instância de HttpClient usando IHttpClientFactory
        using var httpClient = httpClientFactory.CreateClient();
        
        for (int i = 0; i < numberOfRequests; i++)
        {
            int requestId = i + 1; // Para exibir um identificador único por requisição
            tasks[i] = Task.Run(async () =>
            {
                try
                {
                    // Cronômetro para medir o tempo de resposta
                    var stopwatch = System.Diagnostics.Stopwatch.StartNew();

                    // Envia a requisição GET
                    var response = await httpClient.GetAsync(url);

                    stopwatch.Stop();

                    // Lê o conteúdo da resposta
                    var content = await response.Content.ReadAsStringAsync();

                    Console.WriteLine($"[Requisição {requestId}] " +
                                      $"Status: {response.StatusCode}, " +
                                      $"Tempo: {stopwatch.ElapsedMilliseconds} ms, " +
                                      $"Conteúdo: {content}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Requisição {requestId}] Erro: {ex.Message}");
                }
            });
        }

        // Aguarda todas as requisições serem concluídas
        await Task.WhenAll(tasks);
    }
}
