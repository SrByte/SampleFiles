﻿using Microsoft.EntityFrameworkCore;

namespace ProjetoRepositorioGenerico.Data
{
    /// <summary>
    /// Implementação genérica de um repositório usando Entity Framework Core.
    /// </summary>
    /// <typeparam name="T">O tipo de entidade a ser gerenciado pelo repositório.</typeparam>
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly AppDbContext _context;
        private readonly DbSet<T> _dbSet;

        /// <summary>
        /// Inicializa uma nova instância do repositório.
        /// </summary>
        /// <param name="context">Contexto do banco de dados.</param>
        public Repository(AppDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        /// <summary>
        /// Obtém todos os registros da entidade.
        /// </summary>
        /// <returns>Uma lista assíncrona de entidades.</returns>
        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }

        /// <summary>
        /// Obtém um registro pelo seu identificador.
        /// </summary>
        /// <param name="id">O identificador da entidade.</param>
        /// <returns>A entidade correspondente ou nulo se não encontrada.</returns>
        public async Task<T?> GetByIdAsync(int id)
        {
            return await _dbSet.FindAsync(id);
        }

        /// <summary>
        /// Adiciona uma nova entidade ao banco de dados.
        /// </summary>
        /// <param name="entity">A entidade a ser adicionada.</param>
        public async Task AddAsync(T entity)
        {
            await _dbSet.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Atualiza uma entidade existente no banco de dados.
        /// </summary>
        /// <param name="entity">A entidade a ser atualizada.</param>
        public async Task UpdateAsync(T entity)
        {
            _dbSet.Update(entity);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Exclui uma entidade do banco de dados pelo identificador.
        /// </summary>
        /// <param name="id">O identificador da entidade.</param>
        public async Task DeleteAsync(int id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity != null)
            {
                _dbSet.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}
