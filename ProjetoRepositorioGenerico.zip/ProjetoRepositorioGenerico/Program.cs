using Microsoft.EntityFrameworkCore;
using ProjetoRepositorioGenerico.Data;

var builder = WebApplication.CreateBuilder(args);

// Adiciona servi�os ao cont�iner
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("AppDb")); // Banco de dados em mem�ria
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>)); // Registro gen�rico do reposit�rio

var app = builder.Build();

// Configura��o do pipeline HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Produto}/{action=Index}/{id?}"); // Rota padr�o para iniciar em "Produto"

app.Run();
