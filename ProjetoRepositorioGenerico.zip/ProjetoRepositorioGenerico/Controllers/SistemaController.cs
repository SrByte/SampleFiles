﻿using Microsoft.AspNetCore.Mvc;
using ProjetoRepositorioGenerico.Data;
using ProjetoRepositorioGenerico.Models;

namespace ProjetoRepositorioGenerico.Controllers
{
    public class SistemaController : Controller
    {
        private readonly IRepository<Sistema> _repository;

        public SistemaController(IRepository<Sistema> repository)
        {
            _repository = repository;
        }

        // Método assíncrono para buscar todos os sistemas
        public async Task<IActionResult> Index()
        {
            var sistemas = await _repository.GetAllAsync(); // Adicionando o 'await'
            return View(sistemas);
        }

        // Ação para exibir o formulário de criação de um novo sistema
        public IActionResult Create()
        {
            return View();
        }

        // Método assíncrono para criar um novo sistema
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Sistema sistema)
        {
            if (ModelState.IsValid)
            {
                await _repository.AddAsync(sistema); // Adicionando o 'await'
                return RedirectToAction(nameof(Index));
            }
            return View(sistema);
        }
    }
}
