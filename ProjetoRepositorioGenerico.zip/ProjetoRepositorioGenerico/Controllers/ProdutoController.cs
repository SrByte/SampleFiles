﻿using Microsoft.AspNetCore.Mvc;
using ProjetoRepositorioGenerico.Data;
using ProjetoRepositorioGenerico.Models;

namespace ProjetoRepositorioGenerico.Controllers
{
    public class ProdutoController : Controller
    {
        private readonly IRepository<Produto> _repository;

        public ProdutoController(IRepository<Produto> repository)
        {
            _repository = repository;
        }

        public async Task<IActionResult> Index()
        {
            var produtos = await _repository.GetAllAsync();
            return View(produtos);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(Produto produto)
        {
            if (ModelState.IsValid)
            {
                await _repository.AddAsync(produto);
                return RedirectToAction(nameof(Index));
            }
            return View(produto);
        }
    }
}
