﻿using Microsoft.AspNetCore.Mvc;

public class ProdutosController : Controller
{
    public IActionResult Index()
    {
        ViewData["Title"] = "Gestão de Produtos";
        return View();
    }
}
