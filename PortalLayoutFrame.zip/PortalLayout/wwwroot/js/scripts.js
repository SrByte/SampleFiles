﻿// Função para alternar o menu lateral
$("#menu-toggle").click(function () {
    $("#wrapper").toggleClass("toggled");
});

// Função para alternar a seta e o estado do submenu
$('.list-group-item[data-bs-toggle="collapse"]').click(function () {
    const arrow = $(this).find('.menu-arrow i');
    const isExpanded = $(this).attr('aria-expanded') === 'true';

    // Altera a seta conforme o estado do submenu
    arrow.removeClass(isExpanded ? 'fa-chevron-left' : 'fa-chevron-down');
    arrow.addClass(isExpanded ? 'fa-chevron-down' : 'fa-chevron-left');

    // Controla a exibição da linha ao lado dos itens do submenu
    const submenuItems = $(this).next('.collapse').find('.list-group-item');
    submenuItems.each(function () {
        $(this).find('.submenu-line').toggle(isExpanded);
    });
});
