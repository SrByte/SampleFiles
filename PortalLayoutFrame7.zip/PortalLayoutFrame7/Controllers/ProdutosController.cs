﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace SeuProjeto.Controllers
{
    public class ProdutosController : Controller
    {
        private static List<Produto> produtos = new List<Produto>
        {
            new Produto { Nome = "Produto 1", Preco = 10.00M, Quantidade = 100, SeguimentoId = 1 },
            new Produto { Nome = "Produto 2", Preco = 20.00M, Quantidade = 200, SeguimentoId = 2 }
        };

        private static List<Seguimento> seguimentos = new List<Seguimento>
        {
            new Seguimento { Id = 1, Nome = "Alimentos" },
            new Seguimento { Id = 2, Nome = "Eletrônicos" },
            new Seguimento { Id = 3, Nome = "Roupas" }
        };

        public IActionResult Index()
        {
            ViewBag.ListaSeguimentos = seguimentos; // Enviar seguimentos para o combo
            return View(produtos); // Enviar produtos para a tabela
        }

        [HttpGet]
        public IActionResult GetProdutos()
        {
            // Retornar lista de produtos junto com o nome do seguimento
            var lista = produtos.Select(p => new
            {
                p.Nome,
                p.Preco,
                p.Quantidade,
                p.SeguimentoId,
                SeguimentoNome = seguimentos.FirstOrDefault(s => s.Id == p.SeguimentoId)?.Nome
            }).ToList();

            return Json(lista);
        }

        [HttpPost]
        public IActionResult AdicionarOuEditar(Produto produto)
        {
            var existente = produtos.FirstOrDefault(p => p.Nome == produto.Nome);
            if (existente == null)
            {
                // Adicionar novo produto
                produtos.Add(produto);
            }
            else
            {
                // Atualizar produto existente
                existente.Preco = produto.Preco;
                existente.Quantidade = produto.Quantidade;
                existente.SeguimentoId = produto.SeguimentoId;
            }

            return Json(produtos);
        }

        [HttpPost]
        public IActionResult Excluir(string nome)
        {
            var produto = produtos.FirstOrDefault(p => p.Nome == nome);
            if (produto != null)
            {
                produtos.Remove(produto);
            }

            return Json(produtos);
        }
    }

    public class Produto
    {
        public string Nome { get; set; }
        public decimal Preco { get; set; }
        public int Quantidade { get; set; }
        public int SeguimentoId { get; set; }
    }

    public class Seguimento
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
