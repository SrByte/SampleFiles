using Microsoft.AspNetCore.Mvc;
using PayloadProcessor.Models;
using PayloadProcessor.Services;

namespace PayloadProcessor.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PayloadsController : ControllerBase
{
    private readonly PayloadDbContext _context;

    public PayloadsController(PayloadDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public IActionResult PostPayload([FromBody] Payload payload)
    {
        payload.Status = PayloadStatus.Recebido;
        payload.Timestamp = DateTime.UtcNow;
        _context.Payloads.Add(payload);
        _context.SaveChanges();
        return CreatedAtAction(nameof(PostPayload), new { id = payload.Id }, payload);
    }
}
