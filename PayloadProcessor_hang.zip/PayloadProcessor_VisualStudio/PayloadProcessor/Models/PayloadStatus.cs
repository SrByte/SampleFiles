namespace PayloadProcessor.Models;

public enum PayloadStatus
{
    Recebido,
    OptInConfirmado,
    MensagemEnviada
}
