namespace PayloadProcessor.Models;

public class Payload
{
    public int Id { get; set; }
    public string Cpf { get; set; } = string.Empty;
    public string Conteudo { get; set; } = string.Empty;
    public PayloadStatus Status { get; set; }
    public DateTime Timestamp { get; set; }
}
