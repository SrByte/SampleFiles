using Hangfire;
using Hangfire.MemoryStorage;
using Microsoft.EntityFrameworkCore;
using PayloadProcessor;
using PayloadProcessor.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<PayloadDbContext>(opt =>
    opt.UseInMemoryDatabase("PayloadsDb"));

// Hangfire
builder.Services.AddHangfire(config =>
    config.UseMemoryStorage());
builder.Services.AddHangfireServer();
builder.Services.AddScoped<PayloadJobService>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

//app.UseHangfireDashboard();
app.MapControllers();

//// Job recorrente
//RecurringJob.AddOrUpdate<PayloadJobService>(
//    "processar-payloads",
//    job => job.ProcessPayloadsAsync(),
//    Cron.Minutely);

// Job recorrente seguro via DI
using (var scope = app.Services.CreateScope())
{
    var recurringJobManager = scope.ServiceProvider.GetRequiredService<IRecurringJobManager>();
    recurringJobManager.AddOrUpdate<PayloadJobService>(
        "processar-payloads",
        job => job.ProcessPayloadsAsync(),
        Cron.Minutely);
}


app.Run();
