using Microsoft.EntityFrameworkCore;
using PayloadProcessor.Models;

namespace PayloadProcessor;

public class PayloadDbContext : DbContext
{
    public PayloadDbContext(DbContextOptions<PayloadDbContext> options) : base(options) { }

    public DbSet<Payload> Payloads => Set<Payload>();
}
