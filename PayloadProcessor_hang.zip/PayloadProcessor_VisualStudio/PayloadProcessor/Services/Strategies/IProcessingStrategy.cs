using PayloadProcessor.Models;

namespace PayloadProcessor.Services.Strategies;

public interface IProcessingStrategy
{
    Task<bool> ProcessAsync(Payload payload);
}
