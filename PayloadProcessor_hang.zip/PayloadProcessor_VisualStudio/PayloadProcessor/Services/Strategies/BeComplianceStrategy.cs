using PayloadProcessor.Models;

namespace PayloadProcessor.Services.Strategies;

public class BeComplianceStrategy : IProcessingStrategy
{
    public Task<bool> ProcessAsync(Payload payload)
    {
        // Simula que o CPF tem opt-in
        return Task.FromResult(true);
    }
}
