using PayloadProcessor.Models;

namespace PayloadProcessor.Services.Strategies;

public class BlipStrategy : IProcessingStrategy
{
    public Task<bool> ProcessAsync(Payload payload)
    {
        // Simula envio com sucesso
        return Task.FromResult(true);
    }
}
