using PayloadProcessor.Models;
using PayloadProcessor.Services.Strategies;

namespace PayloadProcessor.Services.StateMachine;

public class OptInConfirmedState : IPayloadState
{
    private readonly IProcessingStrategy _strategy;

    public OptInConfirmedState(IProcessingStrategy strategy)
    {
        _strategy = strategy;
    }

    public async Task HandleAsync(Payload payload)
    {
        var result = await _strategy.ProcessAsync(payload);
        if (result)
        {
            payload.Status = PayloadStatus.MensagemEnviada;
        }
    }
}
