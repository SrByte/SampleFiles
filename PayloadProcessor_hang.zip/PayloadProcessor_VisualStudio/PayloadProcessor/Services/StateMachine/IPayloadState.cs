using PayloadProcessor.Models;

namespace PayloadProcessor.Services.StateMachine;

public interface IPayloadState
{
    Task HandleAsync(Payload payload);
}
