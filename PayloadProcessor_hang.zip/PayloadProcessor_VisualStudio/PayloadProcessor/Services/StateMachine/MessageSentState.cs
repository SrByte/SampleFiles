using PayloadProcessor.Models;

namespace PayloadProcessor.Services.StateMachine;

public class MessageSentState : IPayloadState
{
    public Task HandleAsync(Payload payload)
    {
        return Task.CompletedTask; // Already processed
    }
}
