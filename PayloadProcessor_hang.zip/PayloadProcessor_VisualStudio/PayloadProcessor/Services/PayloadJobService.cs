using PayloadProcessor.Models;
using PayloadProcessor.Services.StateMachine;
using PayloadProcessor.Services.Strategies;

namespace PayloadProcessor.Services;

public class PayloadJobService
{
    private readonly PayloadDbContext _context;

    public PayloadJobService(PayloadDbContext context)
    {
        _context = context;
    }

    public async Task ProcessPayloadsAsync()
    {
        var payloads = _context.Payloads
            .Where(p => p.Status == PayloadStatus.Recebido || p.Status == PayloadStatus.OptInConfirmado)
            .ToList();

        foreach (var payload in payloads)
        {
            IPayloadState state = payload.Status switch
            {
                PayloadStatus.Recebido => new ReceivedState(new BeComplianceStrategy()),
                PayloadStatus.OptInConfirmado => new OptInConfirmedState(new BlipStrategy()),
                _ => new MessageSentState()
            };

            await state.HandleAsync(payload);
        }

        await _context.SaveChangesAsync();
    }
}
