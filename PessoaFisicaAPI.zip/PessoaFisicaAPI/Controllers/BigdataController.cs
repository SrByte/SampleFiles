﻿using Microsoft.AspNetCore.Mvc;
using MyApiProject.Models;
using System.Security.Policy;

namespace MyApiProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BigdataController : ControllerBase
    {
        [HttpPost("inject")]
        public IActionResult InjectData([FromBody] AssertivaRoot assertiva)
        {
            if (assertiva == null)
            {
                return BadRequest(new { message = "O JSON 'assertiva' não foi fornecido ou está inválido." });
            }

            // Criar um objeto RootObject vazio
            var bigdata = new RootObject
            {
                Result = new List<Result>
        {
            new Result
            {
                MatchKeys = $"doc{{{assertiva.Cabecalho?.Entrada?.Cpf}}}",
                BasicData = new BasicData
                {
                    TaxIdNumber = assertiva.Cabecalho?.Entrada?.Cpf,
                    
                    TaxIdCountry = "BRAZIL", // Valor fixo, não presente no JSON da assertiva
                    AlternativeIdNumbers = new AlternativeIdNumbers
                    {
                        VoterId = "0259440270124", // Valor fixo, não presente no JSON da assertiva
                        SocialSecurityNumber = "12884654897" // Valor fixo, não presente no JSON da assertiva
                    },
                    Name = assertiva.Resposta?.DadosCadastrais?.Nome,
                    Aliases = new Aliases
                    {
                        CommonName = assertiva.Resposta?.DadosCadastrais?.Nome, // Usando o nome completo como CommonName
                        StandardizedName = assertiva.Resposta?.DadosCadastrais?.Nome // Usando o nome completo como StandardizedName
                    },
                    Gender = assertiva.Resposta?.DadosCadastrais?.Sexo == "Masculino" ? "M" : "F",
                    NameWordCount = assertiva.Resposta?.DadosCadastrais?.Nome?.Split(' ').Length.ToString() ?? "0",
                    NumberOfFullNameNamesakes = "3", // Valor fixo, não presente no JSON da assertiva
                    NameUniquenessScore = "0.994", // Valor fixo, não presente no JSON da assertiva
                    FirstNameUniquenessScore = "0.001", // Valor fixo, não presente no JSON da assertiva
                    FirstAndLastNameUniquenessScore = "0.001", // Valor fixo, não presente no JSON da assertiva
                    BirthDate = assertiva.Resposta?.DadosCadastrais?.DataNascimento,
                    Age = assertiva.Resposta?.DadosCadastrais?.Idade,
                    ZodiacSign = assertiva.Resposta?.DadosCadastrais?.Signo,
                    ChineseSign = "Tiger", // Valor fixo, não presente no JSON da assertiva
                    BirthCountry = "BRASILEIRO(A)", // Valor fixo, não presente no JSON da assertiva
                    MotherName = assertiva.Resposta?.DadosCadastrais?.MaeNome,
                    FatherName = "", // Dado não disponível no JSON da assertiva
                    MaritalStatusData = new object(), // Dado não disponível no JSON da assertiva
                    TaxIdStatus = assertiva.Resposta?.DadosCadastrais?.SituacaoCadastral,
                    TaxIdOrigin = "RECEITA FEDERAL", // Valor fixo, não presente no JSON da assertiva
                    TaxIdFiscalRegion = "SP", // Valor fixo, não presente no JSON da assertiva
                    HasObitIndication = assertiva.Resposta?.DadosCadastrais?.ObitoProvavel?.ToString().ToLower() ?? "false",
                    TaxIdStatusDate = assertiva.Resposta?.DadosCadastrais?.DataSituacaoCadastral,
                    TaxIdStatusRegistrationDate = "1992-05-19T00:00:00Z", // Valor fixo, não presente no JSON da assertiva
                    CreationDate = "2016-08-23T00:00:00Z", // Valor fixo, não presente no JSON da assertiva
                    LastUpdateDate = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ")
                }
            }
        },
                QueryId = assertiva.Cabecalho?.Protocolo,
                ElapsedMilliseconds = "89", // Valor fixo, não presente no JSON da assertiva
                QueryDate = DateTime.UtcNow.ToString("o"), // Data atual no formato ISO 8601
                Status = new Status
                {
                    BasicData = new List<BasicDataStatus>
            {
                new BasicDataStatus { Code = "0", Message = "OK" }
            }
                },
                Evidences = new { } // Dado não disponível no JSON da assertiva
            };

            // Retornar o objeto bigdata como resposta
            return Ok(bigdata);
        }


    }
}
