﻿using Microsoft.AspNetCore.Mvc;
using MyApiProject.Models;

namespace MyApiProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DataController : ControllerBase
    {
        /// <summary>
        /// Recebe um JSON, processa e retorna o mesmo JSON.
        /// </summary>
        /// <param name="input">O objeto JSON enviado pelo cliente.</param>
        /// <returns>O mesmo JSON recebido.</returns>
        [HttpPost]
        public IActionResult ProcessData([FromBody] RootObject? input)
        {
            if (input == null)
            {
                return BadRequest(new
                {
                    Message = "O JSON fornecido é inválido ou está vazio.",
                    StatusCode = 400
                });
            }

            // Validação de exemplo (pode ser opcional)
            if (input.Result == null || input.Result.Count == 0)
            {
                return BadRequest(new
                {
                    Message = "O campo 'Result' está vazio ou ausente.",
                    StatusCode = 400
                });
            }

            // Adicionar logs ou transformações, caso necessário (não altera o objeto original aqui).

            // Retorna o objeto exatamente como recebido.
            return Ok(input);
        }
    }
}
