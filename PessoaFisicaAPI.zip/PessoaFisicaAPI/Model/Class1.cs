﻿public class AssertivaRoot
{
    public Cabecalho Cabecalho { get; set; }
    public Resposta Resposta { get; set; }
    public string Alerta { get; set; }
}

public class Cabecalho
{
    public string DataHora { get; set; }
    public string Protocolo { get; set; }
    public string Produto { get; set; }
    public string Funcionalidade { get; set; }
    public string Finalidade { get; set; }
    public string DescricaoFinalidade { get; set; }
    public bool? Reconsulta { get; set; }
    public Entrada Entrada { get; set; }
}

public class Entrada
{
    public string IdFinalidade { get; set; }
    public string Cpf { get; set; }
}

public class Resposta
{
    public DadosCadastrais DadosCadastrais { get; set; }
}

public class DadosCadastrais
{
    public string? Cpf { get; set; }
    public string? Nome { get; set; }
    public string? Sexo { get; set; }
    public string? DataNascimento { get; set; }
    public int? Idade { get; set; } // Alterado para string
    public string? SituacaoCadastral { get; set; }
    public string? DataSituacaoCadastral { get; set; }
    public string? MaeNome { get; set; }
}

public class RootObject
{
    public List<Result> Result { get; set; }
    public string QueryId { get; set; }
    public string QueryDate { get; set; }
    public Status Status { get; set; }
}

public class Result
{
    public string MatchKeys { get; set; }
    public BasicData BasicData { get; set; }
}

public class BasicData
{
    public string TaxIdNumber { get; set; }
    public string Name { get; set; }
    public string Gender { get; set; }
    public string BirthDate { get; set; }
    public string Age { get; set; }
    public string MotherName { get; set; }
    public string TaxIdStatus { get; set; }
    public string TaxIdStatusDate { get; set; }
    public string HasObitIndication { get; set; }
    public string ZodiacSign { get; set; }
}

public class Status
{
    public List<BasicDataStatus> BasicData { get; set; }
}

public class BasicDataStatus
{
    public string Code { get; set; }
    public string Message { get; set; }
}
