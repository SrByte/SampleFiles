﻿namespace MyApiProject.Models
{
    public class RootObject
    {
        public List<Result>? Result { get; set; }
        public string? QueryId { get; set; }
        public string? ElapsedMilliseconds { get; set; }
        public string? QueryDate { get; set; }
        public Status? Status { get; set; }
        public object? Evidences { get; set; }
    }

    public class Result
    {
        public string? MatchKeys { get; set; }
        public BasicData? BasicData { get; set; }
    }

    public class BasicData
    {
        public string? TaxIdNumber { get; set; }
        public string? TaxIdCountry { get; set; }
        public AlternativeIdNumbers? AlternativeIdNumbers { get; set; }
        public string? Name { get; set; }
        public Aliases? Aliases { get; set; }
        public string? Gender { get; set; }
        public string? NameWordCount { get; set; }
        public string? NumberOfFullNameNamesakes { get; set; }
        public string? NameUniquenessScore { get; set; }
        public string? FirstNameUniquenessScore { get; set; }
        public string? FirstAndLastNameUniquenessScore { get; set; }
        public string? BirthDate { get; set; }
        public string? Age { get; set; }
        public string? ZodiacSign { get; set; }
        public string? ChineseSign { get; set; }
        public string? BirthCountry { get; set; }
        public string? MotherName { get; set; }
        public string? FatherName { get; set; }
        public object? MaritalStatusData { get; set; }
        public string? TaxIdStatus { get; set; }
        public string? TaxIdOrigin { get; set; }
        public string? TaxIdFiscalRegion { get; set; }
        public string? HasObitIndication { get; set; }
        public string? TaxIdStatusDate { get; set; }
        public string? TaxIdStatusRegistrationDate { get; set; }
        public string? CreationDate { get; set; }
        public string? LastUpdateDate { get; set; }
    }

    public class AlternativeIdNumbers
    {
        public string? VoterId { get; set; }
        public string? SocialSecurityNumber { get; set; }
    }

    public class Aliases
    {
        public string? CommonName { get; set; }
        public string? StandardizedName { get; set; }
    }

    public class Status
    {
        public List<BasicDataStatus>? basic_data { get; set; }
    }

    public class BasicDataStatus
    {
        public string? Code { get; set; }
        public string? Message { get; set; }
    }
}
